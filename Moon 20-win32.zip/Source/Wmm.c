
//	This file is a modification from the original file 'wmm_point.c'
//	taken from the World Magnetic Model (WMM) software distributed by
//	US NOAA-NGDC National Geophysical Data Center
//	http://www.ngdc.noaa.gov/Geomagnetic/WMM/DoDWMM.shtml
//
//	LICENSES
//
//	The WMM source code is in the public domain and not licensed or under copyright.
//	The information and software may be used freely by the public. As required by 17 U.S.C. 403,
//	third parties producing copyrighted works consisting predominantly of the material produced by
//	U.S. government agencies must provide notice with such work(s) identifying the U.S. Government material
//	incorporated and stating that such material is not subject to copyright protection.

	#include "WMMHeader.h"
	//#include "WMM_SubLibrary.c"

#define EXPORT __declspec(dllexport) __stdcall

typedef struct {
	WMMtype_CoordGeodetic CoordGeodetic;
	WMMtype_Date UserDate;
	WMMtype_GeoMagneticElements GeoMagneticElements;
	} WMMtype_Data;

	WMMtype_MagneticModel *MagneticModel, *TimedMagneticModel;
	WMMtype_Ellipsoid Ellip;
	WMMtype_Geoid Geoid;
	WMMtype_CoordSpherical CoordSpherical;

int EXPORT WMMInit(char *wmmfile){

	int NumTerms;

	NumTerms = ((WMM_MAX_MODEL_DEGREES + 1) * (WMM_MAX_MODEL_DEGREES + 2) / 2); // WMM_MAX_MODEL_DEGREES is defined in WMM_Header.h
	MagneticModel = WMM_AllocateModelMemory(NumTerms); // For storing the WMM Model parameters
	TimedMagneticModel = WMM_AllocateModelMemory(NumTerms); // For storing the time modified WMM Model parameters
	if(!MagneticModel || !TimedMagneticModel)
		return -1;
	WMM_SetDefaults(&Ellip, MagneticModel, &Geoid); // Set default values and constants
	//WMM_readMagneticModel_Large(filename, MagneticModel); //Uncomment this line when using the 740 model, and comment out the  WMM_readMagneticModel line
	WMM_readMagneticModel(wmmfile ? wmmfile : "WMM.COF", MagneticModel);
	//WMM_InitializeGeoid(&Geoid); // Read the Geoid file
	return 0;

	}

void EXPORT WMMGetElements(WMMtype_Data *Data){
	
	//Data->CoordGeodetic.HeightAboveEllipsoid /= 1000.0; // Convert meters to kilometers
	WMM_GeodeticToSpherical(&Ellip, &Data->CoordGeodetic, &CoordSpherical); // Convert from Geodetic to Spherical Equations: 17-18, WMM Technical report
	WMM_TimelyModifyMagneticModel(&Data->UserDate, MagneticModel, TimedMagneticModel); // Time adjust the coefficients, Equation 19, WMM Technical report
	WMM_Geomag(&Ellip, &CoordSpherical, &Data->CoordGeodetic, TimedMagneticModel, &Data->GeoMagneticElements); // Computes the geoMagnetic field elements and their time change
	//WMM_CalculateGridVariation(&Data->CoordGeodetic, &Data->GeoMagneticElements);
	
	}

void EXPORT WMMCleanup(void){

	WMM_FreeMagneticModelMemory(MagneticModel);
	WMM_FreeMagneticModelMemory(TimedMagneticModel);     
	//if (Geoid.GeoidHeightBuffer)
		//free(Geoid.GeoidHeightBuffer);
	
	}
