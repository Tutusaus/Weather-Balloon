
// Microsoft Visual C++ 6.0 Compiler Settings
//
// Project-Settings-Link-Libraries ...
//
//   Standard:
//     kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib
//     shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib winmm.lib
//   OpenGL:
//     opengl32.lib
//   DirectShow:
//     wmvcore.lib strmiids.lib strmbase.lib
//
// Tools-Options-Directories ...
//
//   Inlcudes:
//     ..\Microsoft Visual Studio\PSDK\INCLUDE
//     ..\Microsoft Visual Studio\DXSDK\INCLUDE
//     ..\Microsoft Visual Studio\WMSDK\WMFSDK9\INCLUDE
//     ..\Microsoft Visual Studio\MSDev98\INCLUDE
//     ..\Microsoft Visual Studio\MSDev98\MFC\INCLUDE
//     ..\Microsoft Visual Studio\MSDev98\ATL\INCLUDE
//
//   Libraries:
//     ..\Microsoft Visual Studio\PSDK\LIB
//     ..\Microsoft Visual Studio\DXSDK\LIB\X86
//     ..\Microsoft Visual Studio\WMSDK\WMFSDK9\LIB
//     ..\Microsoft Visual Studio\MSDev98\LIB
//     ..\Microsoft Visual Studio\MSDev98\MFC\LIB


// OpenGL - DLL Exported Functions

#include "windows.h"
//#include "math.h"

#include "gl.h"//project->settings->link: opengl32.lib
//#include "glu.h"//project->settings->link: glu32.lib
//#include "glaux.h"//project->settings->link: glaux.lib
#include "glext.h"
#include "wglext.h"

typedef struct RGBA2{
	unsigned char r;
	unsigned char g;
	unsigned char b;
	unsigned char a;
	} RGBA;

PFNGLCOMPRESSEDTEXIMAGE2DARBPROC pfnglCompressedTexImage2DARB = NULL;
PFNWGLSWAPINTERVALEXTPROC pfnwglSwapIntervalEXT = NULL;
PFNWGLCHOOSEPIXELFORMATARBPROC pfnwglChoosePixelFormatARB = NULL;

void PASCAL glCompressedTexImage2DARB(unsigned int Target, int Level, unsigned int InternalFormat, int Width, int Height, int Border, int ImageSize, const void *data){

	if(!pfnglCompressedTexImage2DARB)
		pfnglCompressedTexImage2DARB = (PFNGLCOMPRESSEDTEXIMAGE2DARBPROC) wglGetProcAddress("glCompressedTexImage2DARB");
	if(pfnglCompressedTexImage2DARB)
		pfnglCompressedTexImage2DARB(Target, Level, InternalFormat, Width, Height, Border, ImageSize, data);

	}

BOOL PASCAL wglSwapIntervalEXT(int Interval){
	
	if(!pfnwglSwapIntervalEXT)
		pfnwglSwapIntervalEXT = (PFNWGLSWAPINTERVALEXTPROC) wglGetProcAddress("wglSwapIntervalEXT");
	if(pfnwglSwapIntervalEXT)
		return pfnwglSwapIntervalEXT(Interval);
	return FALSE;
	
	}

BOOL PASCAL wglChoosePixelFormatARB(HDC hdc, const int *piAttribIList, const float *pfAttribFList, unsigned int nMaxFormats, int *piFormats, unsigned int *nNumFormats){
	
	if(!pfnwglChoosePixelFormatARB)
		pfnwglChoosePixelFormatARB = (PFNWGLCHOOSEPIXELFORMATARBPROC) wglGetProcAddress("wglChoosePixelFormatARB");
	if(pfnwglChoosePixelFormatARB)
		return pfnwglChoosePixelFormatARB(hdc, piAttribIList, pfAttribFList, nMaxFormats, piFormats, nNumFormats);
	return FALSE;

	}

void PASCAL InitFont(long *ff, long w, long h, RGBA c, RGBA b, long *xx, long *ss, HDC hDC){

	long n, m, o, x, y, *s, *sn[256];
	unsigned char q;

	s = ss;
	for(n = 0; n < 256; n++){
		sn[n] = s;
		for(y = h-1; y >= 0; y--)for(x = 0; x < xx[n]; x++){
			m = GetPixel(hDC, x, n * h + y);
			m = (((m >> 16) & 0xff) + ((m >> 8) & 0xff) + (m & 0xff)) / 3;
			o = 0xff - m;
			*s = (((c.a * m + b.a * o) / 0xff) << 24) |
				(((c.b * m + b.b * o) / 0xff) << 16) |
				(((c.g * m + b.g * o) / 0xff) << 8) |
				((c.r * m + b.r * o) / 0xff);
			s++;
			}
		}
	q = 0; if(!*ff) *ff = glGenLists(256);
	for(n = 0; n < 256; n++){
		glNewList((*ff) + n, GL_COMPILE);
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);
		glDrawPixels(xx[n], h, GL_RGBA, GL_UNSIGNED_BYTE, sn[n]);
		glBitmap(1, 1, 0.0f, 0.0f, (float) xx[n], 0.0f, &q);
		if(n == 13){
			glPopAttrib();
			glBitmap(1, 1, 0.0f, 0.0f, 0.0f, (float)-h, &q);
			glPushAttrib(GL_CURRENT_BIT);
			}
		glEndList();
		}
	
//	long n, m, x, y; unsigned char q;
//	for(n = 0; n < 256; n++)
//		for(y = 0; y < h; y++)
//			for(x = 0; x < w; x++){
//				m = GetPixel(hDC, x, n * h + y);
//				ss[(n * h + (h - y - 1)) * w + x] =
//					(((((m >> 16) & 0xff) + ((m >> 8) & 0xff) + (m & 0xff)) / 4 + 64) << 24) | c;
//				}
//	q=0; if(!*ff) *ff = glGenLists(256);
//	for(n = 0; n < 256; n++){
//		glNewList((*ff) + n, GL_COMPILE);
//		glDrawPixels(w, h, GL_RGBA, GL_UNSIGNED_BYTE, ss + n * h * w);
//		glBitmap(1, 1, 0.0f, 0.0f, (float) xx[n], 0.0f, &q);
//		if(n == 13){
//			glPopAttrib(); glPushAttrib(GL_CURRENT_BIT);
//			glBitmap(1, 1, 0.0f, 0.0f, 0.0f, (float) -h, &q);
//			}
//		glEndList();
//		}

	}

HGLRC PASCAL InitGL(HDC hDC, HINSTANCE hInstance, long f){

	int p = 0;
	HGLRC hRC = 0;
	PIXELFORMATDESCRIPTOR pf = {
		sizeof(pf), 1, PFD_SUPPORT_OPENGL|PFD_DRAW_TO_WINDOW|PFD_DOUBLEBUFFER,
		PFD_TYPE_RGBA, 32, 0, 0, 0, 0, 0, 0, 8, 0, 0, 0, 0, 0, 0, 32, 0, 0,
		PFD_MAIN_PLANE, 0, 0, 0, 0
		};
	if(f > 0)
		pf.dwFlags = f;
	if(f < -1 && f >= -16){
		HWND hWnd;
		HDC DC;
		HGLRC RC = 0;
		UINT n;
		float ff[] = {0,0};
		int fi[] = {
			WGL_DRAW_TO_WINDOW_ARB, GL_TRUE, WGL_SUPPORT_OPENGL_ARB, GL_TRUE,
			WGL_ACCELERATION_ARB, WGL_FULL_ACCELERATION_ARB,
			WGL_COLOR_BITS_ARB, 24, WGL_ALPHA_BITS_ARB, 8,
			WGL_DEPTH_BITS_ARB, 24, WGL_STENCIL_BITS_ARB, 0,
			WGL_DOUBLE_BUFFER_ARB, GL_TRUE, WGL_SAMPLE_BUFFERS_ARB, GL_TRUE,
			WGL_SAMPLES_ARB, -f, 0, 0
			};
        if(hWnd = CreateWindow(
			"STATIC", "gltest", WS_CLIPSIBLINGS | WS_CLIPCHILDREN | WS_OVERLAPPEDWINDOW,
			0, 0, 0, 0, 0, 0, hInstance, 0)){
			if(DC = GetDC(hWnd)){
				if(p = ChoosePixelFormat(DC, &pf))
					if(SetPixelFormat(DC, p, &pf))
						if(RC = wglCreateContext(DC)){
							wglMakeCurrent(DC, RC);
							wglChoosePixelFormatARB(DC, &fi[0], &ff[0], 1, &p, &n);
							wglMakeCurrent(0, 0);
							wglDeleteContext(RC);
							}
				ReleaseDC(hWnd, DC);
				}
			DestroyWindow(hWnd);
			}
		}
	if(!p)
		p = ChoosePixelFormat(hDC, &pf);
	if(p)
		if(SetPixelFormat(hDC, p, &pf))
			if(hRC = wglCreateContext(hDC))
				if(wglMakeCurrent(hDC, hRC))
					return hRC;
	return 0;
	}

void PASCAL CleanupGL(){

	wglDeleteContext(wglGetCurrentContext());

	}
